dotnet run
