#!/bin/sh
dotnet run
